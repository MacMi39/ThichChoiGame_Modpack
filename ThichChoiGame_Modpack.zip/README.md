# Description
Modpack được tạo bởi đội ngũ modder thuộc server Thích Chơi Game, thuộc bản quyền của Thích chơi game server.

# Installation
Mod Manager (Preferred)
 1. Create a new profile (do not re-use a profile that has been used for other modpacks)
 2. Install TCG

Manual
 1. Download all dependencies first
 2. Download TCG last and copy all files to the BepInEx folder
 ## Information
For help requests, suggestions, bug reports, or to just follow the development, join the discord! https://discord.gg/6ugfCKvxEP

For existing worlds you must place the altars and vegvisirs by installing this mod: https://valheim.thunderstore.io/package/JereKuusela/Upgrade_World/
Then run these commands:

- `upgrade EVA`
- `start`
# Known issues
 - None.



# Change log
v0.1.0
 - combined all the modpack that work in Mistland update.